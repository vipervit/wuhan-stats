# wuhan-stats
Selenium-based alert for updates of Wuhan virus statistics.

Currently for Mac only. Generates alert using Mac Notifications as soon as new statistics are available on https://www.worldometers.info/coronavirus/  
