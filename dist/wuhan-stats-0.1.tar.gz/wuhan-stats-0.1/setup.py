from setuptools import setup, find_packages
setup(
    name = 'wuhan-stats',
    packages = find_packages(),
    version='0.1'
)
